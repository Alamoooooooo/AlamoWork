# ijcai-17-top1-single-mole-solution

- file 文件中包含答辩ppt和解决方案详细文档
- 比赛链接：https://tianchi.aliyun.com/competition/introduction.htm?spm=5176.11163580.0.0.74c864f0mJ1mhl&raceId=231591
